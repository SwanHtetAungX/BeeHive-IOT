var AWS = require('aws-sdk');
var iotdata = new AWS.IotData({ endpoint: 'aeejowedc1a5m-ats.iot.us-east-1.amazonaws.com' });

exports.handler = function (event, context, callback) {
    var temperature = parseFloat(event.temperature.replace('°C', ''));
    var humidity = parseFloat(event.humidity.replace('%', ''));
    var actions = [];

    
    if (temperature < 34) {
        actions.push('Activate heating system');
    } else if (temperature > 36) {
        actions.push('Activate cooling system');
    } else if (humidity < 60 || humidity > 60) {
        actions.push('Activate humidifier system');
    } else {
        actions.push('No Action Required');
    }

    
    event.actions = actions;

    
    var params = {
        topic: 'BeeHiveData',
        payload: JSON.stringify({"Action":actions}),
        qos: 0
    };

    iotdata.publish(params, function (err, data) {
        if (err) {
            console.log('Error publishing IoT data:', err);
            callback(err);
        } else {
            console.log('Successfully published IoT data:', data);
            callback(null, 'Successfully processed event');
        }
    });
};
