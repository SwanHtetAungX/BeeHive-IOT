const AWS = require('aws-sdk');
const sns = new AWS.SNS();

// Optimum levels for sensors
const temperatureOptimum = 35; 
const humidityOptimum = 60;    
const soundOptimum = 150;      

exports.handler = async (event) => {
    // Parse incoming sensor data
    const temperature = parseFloat(event.temperature.replace('°C', ''));
    const humidity = parseFloat(event.humidity.replace('%', ''));
    const soundLevel = parseFloat(event.acousticSensor.replace('Hz',''));

    // Check conditions and trigger notifications
    const notifications = [];

    if (temperature !== temperatureOptimum) {
        notifications.push("Temperature is not at optimum level: " + temperature + "°C");
    }

    if (humidity !== humidityOptimum) {
        notifications.push("Humidity is not at optimum level: " + humidity + "%");
    }

    if (soundLevel !== soundOptimum) {
        notifications.push("Sound level is not at optimum level: " + soundLevel + "Hz");
    }

    if (event.imageSensor === "Object Detected") {
        notifications.push("Object detected by image sensor");
    }

    // Send notifications
    for (const notification of notifications) {
        await sendNotification(notification);
    }
};

async function sendNotification(message) {
    const params = {
        Message: message,
        TopicArn: 'arn:aws:sns:us-east-1:273151493109:HiveInsight_topic' 
    };

    try {
        const data = await sns.publish(params).promise();
        console.log("Notification sent successfully:", data.MessageId);
    } catch (error) {
        console.error("Error sending notification:", error);
    }
}
