import boto3
import json
import csv
from io import StringIO

dynamodb = boto3.client('dynamodb')
s3_client = boto3.client('s3')
bucket_name = 'hiveinsight-data'
table_name = 'HiveInsight_db'
file_name = 'dynamodb_data.csv'

def lambda_handler(event, context):
    for record in event['Records']:
        if record['eventName'] == 'INSERT':
            response = dynamodb.scan(TableName=table_name)
            items = response['Items']
            
            csv_buffer = StringIO()
            csv_writer = csv.writer(csv_buffer)
            
            # Remove the code that writes the headers
            # if items:
            #     headers = items[0].keys()
            #     csv_writer.writerow(headers)
            
            for item in items:
                row = [item[key]['S'] if 'S' in item[key] else item[key]['N'] for key in item.keys()]
                csv_writer.writerow(row)
            
            s3_client.put_object(Bucket=bucket_name, Key=file_name, Body=csv_buffer.getvalue())
            break



