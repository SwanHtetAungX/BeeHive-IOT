import json
import boto3
import time

athena = boto3.client('athena')

def lambda_handler(event, context):
    params = {
        'QueryString': """
            SELECT
                DATE(from_iso8601_timestamp(timestamp)) AS date,
                AVG(CAST(SUBSTRING(temperature, 1, LENGTH(temperature) - 2) AS DOUBLE)) AS avg_temperature,
                AVG(CAST(SUBSTRING(humidity, 1, LENGTH(humidity) - 1) AS DOUBLE)) AS avg_humidity
            FROM
                bee_hive_analysis.hive_data
            GROUP BY
                DATE(from_iso8601_timestamp(timestamp))
            ORDER BY
                date;
        """,
        'QueryExecutionContext': {
            'Database': 'bee_hive_analysis'
        },
        'ResultConfiguration': {
            'OutputLocation': 's3://analysiss/'
        }
    }

    try:
        start_query_execution_response = athena.start_query_execution(**params)
        query_execution_id = start_query_execution_response['QueryExecutionId']

        query_status = 'RUNNING'
        while query_status in ['RUNNING', 'QUEUED']:
            query_execution_response = athena.get_query_execution(QueryExecutionId=query_execution_id)
            query_status = query_execution_response['QueryExecution']['Status']['State']
            time.sleep(1)  # Wait 1 second before checking again

        if query_status in ['FAILED', 'CANCELLED']:
            raise Exception(f'Query failed with status: {query_status}')

        # Fetch the query results
        query_results_response = athena.get_query_results(QueryExecutionId=query_execution_id)
        rows = query_results_response['ResultSet']['Rows']

        processed_results = [
            {
                'date': row['Data'][0]['VarCharValue'],
                'avg_temperature': float(row['Data'][1]['VarCharValue']),
                'avg_humidity': float(row['Data'][2]['VarCharValue'])
            }
            for row in rows[1:]  # Skip the first row, which contains column names
        ]

        return {
            'statusCode': 200,
            'body': json.dumps(processed_results)
        }
    except Exception as error:
        print(error)  # Log the error for debugging
        return {
            'statusCode': 500,
            'body': json.dumps(str(error))
        }
